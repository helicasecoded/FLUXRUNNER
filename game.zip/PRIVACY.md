# Privacy Policy - Flux Runner

Last updated: 18 November 2026

Flux Runner ("the game") is a free game for Android and the web.

## Your game data
Your progress (unlocked levels, lives, language and mode choice) is saved only on your own device, in the app or browser storage. We run no server, there is no account or login, and we do not collect your name, email, contacts, photos or files.

## Permissions
The app uses: Internet and network state (to load ads), and the advertising ID permission (used by the ad network below). It does not ask for camera, microphone, contacts, storage or precise location.

## Ads
The game shows banner ads and rewarded video ads (watch a video to get +1 life, a hint or a level skip). Ads are provided by Start.io (formerly StartApp). The ad network may collect your device advertising ID, IP address, device and app information, and approximate location to show, measure and personalise ads. We do not receive this data. Start.io's privacy policy: https://www.start.io/policy/privacy-policy

You can reset your advertising ID or opt out of ad personalisation in your phone's settings (Settings > Privacy > Ads).

## Sharing
The "Challenge" button opens your phone's share menu. Nothing is sent unless you choose to share.

## Children
The game is not directed at children under 13.

## Changes
If this policy changes, the date above will be updated.

## Contact
[YOUR EMAIL]
