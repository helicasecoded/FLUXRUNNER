# Privacy Policy - Flux Runner

Last updated: [DATE]

Flux Runner is a game that stores your progress (unlocked levels, lives, language and joke-mode choice) only on your own device. We do not run a server, we do not ask you to log in, and we do not collect your name, email or contacts.

**Ads.** The app shows ads (banner and rewarded) provided by a third-party ad network ([AD NETWORK NAME]). The ad network may collect your device advertising ID, approximate location and usage data to show and measure ads. Please read their privacy policy: [LINK]. You can reset or opt out of personalized ads in your phone settings.

**Sharing.** The "Challenge" button opens your phone's share menu. Nothing is sent unless you choose to share.

**Children.** The app is not directed at children under 13 and uses joking language.

**Contact.** [YOUR EMAIL]
