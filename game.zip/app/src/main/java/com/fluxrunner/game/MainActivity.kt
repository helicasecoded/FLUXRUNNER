package com.fluxrunner.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

const val START_IO_APP_ID = "210676724"
const val UNITY_GAME_ID = "800442634"
const val UNITY_REWARDED = "BP_Rewarded_Android"
const val UNITY_INTERSTITIAL = "BP_Interstitial_Android"
const val UNITY_BANNER = "BP_Banner_Android"

// AD ORDER for life / hint / skip. The first one that has an ad wins. Change the order here.
// S_REW = Start.io rewarded, U_REW = Unity rewarded, S_INT = Start.io interstitial, U_INT = Unity interstitial
val AD_ORDER = listOf("S_REW", "U_REW", "S_INT", "U_INT")

class Bridge(private val a: MainActivity) {
    @JavascriptInterface
    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        a.startActivity(Intent.createChooser(i, null))
    }

    @JavascriptInterface
    fun showRewarded() = a.runOnUiThread { a.showRewarded() }

    @JavascriptInterface
    fun refreshBanner() = a.runOnUiThread { a.refreshBanner(false) }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bannerBox: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private var lastBanner = 0L
    private var busy = false
    private var unityReady = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StartAppSDK.initParams(this, START_IO_APP_ID)
            .setReturnAdsEnabled(false)
            .init()
        StartAppAd.disableSplash()
        UnityAds.initialize(applicationContext, UNITY_GAME_ID, false, object : IUnityAdsInitializationListener {
            override fun onInitializationComplete() { unityReady = true }
            override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {}
        })

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF2B1D1D.toInt())
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "Android")

        bannerBox = FrameLayout(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF2B1D1D.toInt())
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bannerBox, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(root)
        hideBars()
        refreshBanner(true)
        web.loadUrl("file:///android_asset/index.html")
    }

    // ---------- Banner ----------
    // New banner on every screen change or death (at most once per 20 seconds, ad network rules).
    // Start.io banner first. If it shows nothing after 6 seconds, a Unity banner replaces it.
    fun refreshBanner(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastBanner < 20000) return
        lastBanner = now
        bannerBox.removeAllViews()
        val s = Banner(this)
        bannerBox.addView(s, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        handler.postDelayed({
            if (bannerBox.childCount == 1 && bannerBox.getChildAt(0) === s && s.height < 5 && unityReady) {
                bannerBox.removeAllViews()
                val u = BannerView(this, UNITY_BANNER, UnityBannerSize(320, 50))
                bannerBox.addView(u, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
                u.load()
            }
        }, 6000)
    }

    // ---------- Reward ad for +1 life, hint, level skip ----------
    fun showRewarded() {
        if (busy) return
        busy = true
        tryAd(0)
    }

    private fun tryAd(i: Int) {
        if (i >= AD_ORDER.size) { finishAd(false); return }
        val next = { tryAd(i + 1) }
        when (AD_ORDER[i]) {
            "S_REW" -> startio(StartAppAd.AdMode.REWARDED_VIDEO, next)
            "U_REW" -> unity(UNITY_REWARDED, true, next)
            "S_INT" -> startio(StartAppAd.AdMode.AUTOMATIC, next)
            "U_INT" -> unity(UNITY_INTERSTITIAL, false, next)
            else -> next()
        }
    }

    // Reward: rewarded video must be completed; for a normal full-screen ad, showing and closing it is enough.
    private fun startio(mode: StartAppAd.AdMode, onFail: () -> Unit) {
        var rewarded = mode != StartAppAd.AdMode.REWARDED_VIDEO
        var done = false
        val ad = StartAppAd(this)
        val timeout = Runnable { if (!done) { done = true; onFail() } }
        handler.postDelayed(timeout, 12000)
        ad.setVideoListener { rewarded = true }
        ad.loadAd(mode, object : AdEventListener {
            override fun onReceiveAd(a: Ad) {
                if (done) return
                done = true
                handler.removeCallbacks(timeout)
                ad.showAd(object : AdDisplayListener {
                    override fun adHidden(a: Ad?) = finishAd(rewarded)
                    override fun adDisplayed(a: Ad?) {}
                    override fun adClicked(a: Ad?) {}
                    override fun adNotDisplayed(a: Ad?) = onFail()
                })
            }
            override fun onFailedToReceiveAd(a: Ad?) {
                if (done) return
                done = true
                handler.removeCallbacks(timeout)
                onFail()
            }
        })
    }

    private fun unity(placement: String, needComplete: Boolean, onFail: () -> Unit) {
        if (!unityReady) { onFail(); return }
        var done = false
        val timeout = Runnable { if (!done) { done = true; onFail() } }
        handler.postDelayed(timeout, 12000)
        UnityAds.load(placement, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(p: String?) {
                if (done) return
                done = true
                handler.removeCallbacks(timeout)
                UnityAds.show(this@MainActivity, placement, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(p: String?, e: UnityAds.UnityAdsShowError?, m: String?) = onFail()
                    override fun onUnityAdsShowStart(p: String?) {}
                    override fun onUnityAdsShowClick(p: String?) {}
                    override fun onUnityAdsShowComplete(p: String?, s: UnityAds.UnityAdsShowCompletionState?) {
                        finishAd(!needComplete || s == UnityAds.UnityAdsShowCompletionState.COMPLETED)
                    }
                })
            }
            override fun onUnityAdsFailedToLoad(p: String?, e: UnityAds.UnityAdsLoadError?, m: String?) {
                if (done) return
                done = true
                handler.removeCallbacks(timeout)
                onFail()
            }
        })
    }

    private fun finishAd(ok: Boolean) {
        if (!busy) return
        busy = false
        handler.postDelayed({
            if (!ok) Toast.makeText(this, "Ad not available. Try again in a bit.", Toast.LENGTH_SHORT).show()
            web.evaluateJavascript("window.__adDone&&window.__adDone($ok)", null)
        }, 300)
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("if(scr=='menu'||scr=='consent'){'exit'}else{toMenu();'ok'}") {
            if (it != null && it.contains("exit")) finish()
        }
    }
}
