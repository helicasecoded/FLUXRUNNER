package com.fluxrunner.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener

const val START_IO_APP_ID = "210676724"

class Bridge(private val a: MainActivity) {
    @JavascriptInterface
    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        a.startActivity(Intent.createChooser(i, null))
    }

    @JavascriptInterface
    fun showRewarded() = a.runOnUiThread { a.showRewarded() }

    @JavascriptInterface
    fun refreshBanner() = a.runOnUiThread { a.refreshBanner(false) }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bannerBox: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private var lastBanner = 0L
    private var busy = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StartAppSDK.initParams(this, START_IO_APP_ID)
            .setReturnAdsEnabled(false)
            .init()
        StartAppAd.disableSplash()

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF2B1D1D.toInt())
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "Android")

        bannerBox = FrameLayout(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF2B1D1D.toInt())
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bannerBox, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(root)
        hideBars()
        refreshBanner(true)
        web.loadUrl("file:///android_asset/index.html")
    }

    // New banner on every screen change or death (at most once per 20 seconds, ad network rules)
    fun refreshBanner(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastBanner < 20000) return
        lastBanner = now
        bannerBox.removeAllViews()
        bannerBox.addView(Banner(this), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
    }

    // Rewarded video: used for +1 life, hint and level skip. Reward only if the video was completed.
    fun showRewarded() {
        if (busy) return
        busy = true
        var rewarded = false
        var shown = false
        val ad = StartAppAd(this)
        val timeout = Runnable { if (!shown) finishAd(false) }
        handler.postDelayed(timeout, 15000)
        ad.setVideoListener { rewarded = true }
        ad.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
            override fun onReceiveAd(a: Ad) {
                if (shown || !busy) return
                shown = true
                handler.removeCallbacks(timeout)
                ad.showAd(object : AdDisplayListener {
                    override fun adHidden(a: Ad?) = finishAd(rewarded)
                    override fun adDisplayed(a: Ad?) {}
                    override fun adClicked(a: Ad?) {}
                    override fun adNotDisplayed(a: Ad?) = finishAd(false)
                })
            }
            override fun onFailedToReceiveAd(a: Ad?) {
                if (!shown) { handler.removeCallbacks(timeout); finishAd(false) }
            }
        })
    }

    private fun finishAd(ok: Boolean) {
        if (!busy) return
        busy = false
        handler.postDelayed({
            if (!ok) Toast.makeText(this, "Ad not available. Try again in a bit.", Toast.LENGTH_SHORT).show()
            web.evaluateJavascript("window.__adDone&&window.__adDone($ok)", null)
        }, 300)
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("if(scr=='menu'||scr=='consent'){'exit'}else{toMenu();'ok'}") {
            if (it != null && it.contains("exit")) finish()
        }
    }
}
