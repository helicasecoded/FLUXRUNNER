package com.fluxrunner.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.startapp.sdk.ads.banner.Banner
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.StartAppSDK
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

const val START_IO_APP_ID = "210676724"
const val UNITY_GAME_ID = "800442634"
const val UNITY_REWARDED = "BP_Rewarded_Android"
const val UNITY_INTERSTITIAL = "BP_Interstitial_Android"
const val UNITY_BANNER = "BP_Banner_Android"
const val ADMOB_BANNER = "ca-app-pub-5778694776035119/7679722926"
const val ADMOB_INTERSTITIAL = "ca-app-pub-5778694776035119/1720498432"
const val ADMOB_REWARDED = "ca-app-pub-5778694776035119/1337355054"

const val REWARDED_COOLDOWN_MS = 60_000L   // a rewarded video at most once per minute
const val BANNER_MIN_GAP_MS = 30_000L      // banner refresh at most every 30 seconds
const val WAIT_FOR_ADS_MS = 1000           // if no ad is ready, wait at most 1 second

class Bridge(private val a: MainActivity) {
    @JavascriptInterface
    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        a.startActivity(Intent.createChooser(i, null))
    }

    @JavascriptInterface
    fun showRewarded() = a.runOnUiThread { a.showRewarded() }

    @JavascriptInterface
    fun refreshBanner() = a.runOnUiThread { a.refreshBanner(false) }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bannerBox: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var unityReady = false
    private var lastBanner = 0L
    private var lastRewarded = 0L
    private var bannerGen = 0
    private var curAdView: AdView? = null
    private var curAllowRew = true

    // Ads that are already loaded and ready to show (priority: AdMob, Unity, Start.io)
    private var aRew: RewardedAd? = null
    private var aInt: InterstitialAd? = null
    private var uRew = false
    private var uInt = false
    private var sRew: StartAppAd? = null
    private var sInt: StartAppAd? = null
    private val loading = mutableSetOf<String>()

    private val tick = object : Runnable {
        override fun run() {
            loading.clear()
            preload()
            handler.postDelayed(this, 60_000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StartAppSDK.initParams(this, START_IO_APP_ID).setReturnAdsEnabled(false).init()
        StartAppAd.disableSplash()
        MobileAds.initialize(this) { preload() }
        UnityAds.initialize(applicationContext, UNITY_GAME_ID, false, object : IUnityAdsInitializationListener {
            override fun onInitializationComplete() { unityReady = true; preload() }
            override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {}
        })

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF2B1D1D.toInt())
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "Android")

        bannerBox = FrameLayout(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF2B1D1D.toInt())
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bannerBox, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(root)
        hideBars()
        refreshBanner(true)
        preload()
        handler.postDelayed(tick, 5000)
        web.loadUrl("file:///android_asset/index.html")
    }

    // ---------- Preload: keep one ad of each kind ready ----------
    private fun preload() {
        val req = AdRequest.Builder().build()
        if (aRew == null && loading.add("aRew")) {
            RewardedAd.load(this, ADMOB_REWARDED, req, object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { aRew = ad; loading.remove("aRew") }
                override fun onAdFailedToLoad(e: LoadAdError) { loading.remove("aRew") }
            })
        }
        if (aInt == null && loading.add("aInt")) {
            InterstitialAd.load(this, ADMOB_INTERSTITIAL, req, object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { aInt = ad; loading.remove("aInt") }
                override fun onAdFailedToLoad(e: LoadAdError) { loading.remove("aInt") }
            })
        }
        if (unityReady) {
            if (!uRew && loading.add("uRew")) unityLoad(UNITY_REWARDED, "uRew") { uRew = true }
            if (!uInt && loading.add("uInt")) unityLoad(UNITY_INTERSTITIAL, "uInt") { uInt = true }
        }
        if (sRew == null && loading.add("sRew")) startLoad(StartAppAd.AdMode.REWARDED_VIDEO, "sRew") { sRew = it }
        if (sInt == null && loading.add("sInt")) startLoad(StartAppAd.AdMode.AUTOMATIC, "sInt") { sInt = it }
    }

    private fun unityLoad(placement: String, key: String, ok: () -> Unit) {
        UnityAds.load(placement, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(p: String?) { ok(); loading.remove(key) }
            override fun onUnityAdsFailedToLoad(p: String?, e: UnityAds.UnityAdsLoadError?, m: String?) { loading.remove(key) }
        })
    }

    private fun startLoad(mode: StartAppAd.AdMode, key: String, ok: (StartAppAd) -> Unit) {
        val ad = StartAppAd(this)
        ad.loadAd(mode, object : AdEventListener {
            override fun onReceiveAd(a: Ad) { ok(ad); loading.remove(key) }
            override fun onFailedToReceiveAd(a: Ad?) { loading.remove(key) }
        })
    }

    // ---------- Reward ad (life / hint / skip), only when the player asks for it ----------
    // Rewarded video allowed once per minute. Order: AdMob, Unity, Start.io. Otherwise the same order for interstitials.
    fun showRewarded() {
        if (busy) return
        busy = true
        curAllowRew = System.currentTimeMillis() - lastRewarded >= REWARDED_COOLDOWN_MS
        attempt(0)
    }

    private fun isReady(k: String) = when (k) {
        "aRew" -> aRew != null
        "uRew" -> uRew
        "sRew" -> sRew != null
        "aInt" -> aInt != null
        "uInt" -> uInt
        else -> sInt != null
    }

    private fun attempt(waited: Int) {
        val order = if (curAllowRew) listOf("aRew", "uRew", "sRew", "aInt", "uInt", "sInt") else listOf("aInt", "uInt", "sInt")
        for (k in order) {
            if (isReady(k)) { present(k); return }
        }
        if (waited < WAIT_FOR_ADS_MS) {
            handler.postDelayed({ attempt(waited + 250) }, 250)
            return
        }
        finishAd(false)
    }

    private fun failed() { preload(); attempt(WAIT_FOR_ADS_MS) }

    private fun done(k: String, ok: Boolean) {
        if (ok && k.endsWith("Rew")) lastRewarded = System.currentTimeMillis()
        preload()
        finishAd(ok)
    }

    private fun present(k: String) {
        when (k) {
            "aRew" -> {
                val ad = aRew!!
                aRew = null
                var earned = false
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() = done(k, earned)
                    override fun onAdFailedToShowFullScreenContent(e: AdError) = failed()
                }
                ad.show(this) { earned = true }
            }
            "aInt" -> {
                val ad = aInt!!
                aInt = null
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() = done(k, true)
                    override fun onAdFailedToShowFullScreenContent(e: AdError) = failed()
                }
                ad.show(this)
            }
            "uRew", "uInt" -> {
                val rew = k == "uRew"
                if (rew) uRew = false else uInt = false
                UnityAds.show(this, if (rew) UNITY_REWARDED else UNITY_INTERSTITIAL, UnityAdsShowOptions(), object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(p: String?, e: UnityAds.UnityAdsShowError?, m: String?) = failed()
                    override fun onUnityAdsShowStart(p: String?) {}
                    override fun onUnityAdsShowClick(p: String?) {}
                    override fun onUnityAdsShowComplete(p: String?, s: UnityAds.UnityAdsShowCompletionState?) {
                        done(k, !rew || s == UnityAds.UnityAdsShowCompletionState.COMPLETED)
                    }
                })
            }
            else -> {
                val rew = k == "sRew"
                val ad = (if (rew) sRew else sInt)!!
                if (rew) sRew = null else sInt = null
                var earned = false
                if (rew) ad.setVideoListener { earned = true }
                ad.showAd(object : AdDisplayListener {
                    override fun adHidden(a: Ad?) = done(k, !rew || earned)
                    override fun adDisplayed(a: Ad?) {}
                    override fun adClicked(a: Ad?) {}
                    override fun adNotDisplayed(a: Ad?) = failed()
                })
            }
        }
    }

    private fun finishAd(ok: Boolean) {
        if (!busy) return
        busy = false
        handler.postDelayed({
            if (!ok) Toast.makeText(this, "Ad not available. Try again in a bit.", Toast.LENGTH_SHORT).show()
            web.evaluateJavascript("window.__adDone&&window.__adDone($ok)", null)
        }, 300)
    }

    // ---------- Banner: AdMob, then Unity, then Start.io ----------
    fun refreshBanner(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastBanner < BANNER_MIN_GAP_MS) return
        lastBanner = now
        val gen = ++bannerGen
        curAdView?.destroy()
        bannerBox.removeAllViews()
        val av = AdView(this)
        av.setAdSize(AdSize.BANNER)
        av.adUnitId = ADMOB_BANNER
        av.adListener = object : AdListener() {
            override fun onAdFailedToLoad(e: LoadAdError) { if (gen == bannerGen) unityBanner(gen) }
        }
        curAdView = av
        bannerBox.addView(av, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        av.loadAd(AdRequest.Builder().build())
    }

    private fun unityBanner(gen: Int) {
        if (!unityReady) { startBanner(gen); return }
        curAdView?.destroy()
        curAdView = null
        bannerBox.removeAllViews()
        val u = BannerView(this, UNITY_BANNER, UnityBannerSize(320, 50))
        u.listener = object : BannerView.IListener {
            override fun onBannerLoaded(b: BannerView?) {}
            override fun onBannerShown(b: BannerView?) {}
            override fun onBannerClick(b: BannerView?) {}
            override fun onBannerFailedToLoad(b: BannerView?, e: BannerErrorInfo?) { if (gen == bannerGen) startBanner(gen) }
            override fun onBannerLeftApplication(b: BannerView?) {}
        }
        bannerBox.addView(u, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        u.load()
    }

    private fun startBanner(gen: Int) {
        if (gen != bannerGen) return
        bannerBox.removeAllViews()
        bannerBox.addView(Banner(this), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("if(scr=='menu'||scr=='consent'){'exit'}else{toMenu();'ok'}") {
            if (it != null && it.contains("exit")) finish()
        }
    }
}
