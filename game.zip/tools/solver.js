// Level bot: generates levels, tries to solve each one by itself, re-rolls unsolvable ones.
// Usage: node tools/solver.js [from] [to] [index.html]   -> writes salts.js
const fs=require('fs');
const FROM=+(process.argv[2]||0),TO=+(process.argv[3]||1000),FILE=process.argv[4]||'index.html';
let src=fs.readFileSync(FILE,'utf8');src=src.slice(src.indexOf('<script>')+8,src.lastIndexOf('</script>'));src=fs.readFileSync('lang.js','utf8')+'\n'+src;
const el={style:{},getContext:()=>new Proxy({},{get:()=>()=>{},set:()=>true}),addEventListener(){},classList:{add(){},remove(){}}};
global.document={getElementById:()=>el};global.addEventListener=()=>{};global.requestAnimationFrame=()=>{};global.navigator={};global.window={};global.SALT={};
const BOT=`
;globalThis.__bot=(function(){
const ACT=[[0,0,0],[0,1,0],[1,0,0],[0,1,1],[1,0,1],[0,0,1],[1,1,0],[1,1,1]];
const isDev=i=>i>=24&&(i-24)%25==0&&(i-24)/25<DEVIL.length;
function solve(i,sl,W,M,maxD,dth,cap){
 const v=(i<19||isDev(i))?L[i]:gen(i,sl);L[i]=v;lv=i;deaths[i]=dth||0;scr='play';load();
 let DIED=0,WON=0;die=function(){DIED=1};win=function(){WON=1};
 const mvp=v.p.filter(p=>p[5]);
 const snap=()=>structuredClone({P,t,tr,cr,K,O,pcd,D,coy,buf,jp,air,E,mp:mvp.map(p=>[p[0],p.dx||0])});
 const rest=s=>{const c=structuredClone(s);P=c.P;t=c.t;tr=c.tr;cr=c.cr;K=c.K;O=c.O;pcd=c.pcd;D=c.D;coy=c.coy;buf=c.buf;jp=c.jp;air=c.air;E=c.E;mvp.forEach((p,k)=>{p[0]=c.mp[k][0];p.dx=c.mp[k][1]})};
 const h=()=>{const prog=(D.m?1:0)+(K?1:0)+(O?1:0)+Object.keys(E.fired).length;let g,ox=10,oy=4,r;const pd=v.tr&&v.tr.find((q,n)=>!E.fired[n]&&q.o.some(o=>o[0]=='d'));if(pd)r=Math.abs(P.x+10-(pd.a[0]+15));else if(v.tp&&!D.m)r=Math.abs(P.x+10-(v.tp[0]+25));else{if(v.lk&&!K)g=v.ky;else if(v.bt&&!O&&v.p.some(p=>p[6]))g=v.bt;else{g=E.alt||[D.x,D.y];ox=12;oy=17}r=Math.abs(P.x+10-(g[0]+ox))+.5*Math.abs(P.y+15-(g[1]+oy))}return r-1000*prog};
 const T0=Date.now();let beam=[{s:snap(),h:h(),par:null,a:-1}],best=1e9;
 for(let d=0;d<maxD;d++){
  if(Date.now()-T0>(cap||6000))return{ok:0,why:'too slow',best};
  const cand=new Map();
  for(const nd of beam){
   for(let a=0;a<ACT.length;a++){
    rest(nd.s);key.l=ACT[a][0];key.r=ACT[a][1];key.j=ACT[a][2];DIED=0;WON=0;
    for(let f=0;f<M&&!DIED&&!WON;f++)step();
    if(WON){let n=0,q=nd;while(q&&q.par){n++;q=q.par}return{ok:1,frames:(n+1)*M}}
    if(DIED)continue;
    const hh=h(),kk=((P.x/4)|0)+','+((P.y/4)|0)+','+((P.vy/3)|0)+','+(K|0)+(O|0)+(D.m|0)+','+((P.vx/1.5)|0)+','+Object.keys(E.fired).length;
    const o=cand.get(kk);if(!o||hh<o.h)cand.set(kk,{s:snap(),h:hh,par:nd,a});
   }
   nd.s=null;
  }
  beam=[...cand.values()].sort((a,b)=>a.h-b.h).slice(0,W);
  if(!beam.length)return{ok:0,why:'all dead',best};
  best=Math.min(best,beam[0].h);if(globalThis.DBG&&d%25==0)console.error('d',d,'h',beam[0].h|0,'n',beam.length);
 }
 return{ok:0,why:'timeout',best};
}
return{solve,L,isDev};
})();`;
eval(src+BOT);
globalThis.DBG=process.env.DBG;const B=globalThis.__bot,SALTS={},bad=[],bant={},t0=Date.now();let tf=0,ok=0;
for(let i=FROM;i<TO;i++){
 let r,sl=0;const fixed=i<19||B.isDev(i);
 for(;sl<(fixed?1:12);sl++){r=B.solve(i,sl,60,6,350);if(r.ok)break}
 if(r.ok){ok++;tf+=r.frames;if(sl>0)SALTS[i]=sl;if(process.env.TW){const bl=[];for(let k=0;k<16;k++){global.FORCE=k;const r2=B.solve(i,sl,40,6,250,1,3500);if(!r2.ok)bl.push(k)}global.FORCE=undefined;if(bl.length)bant[i]=bl}}else bad.push(i);
 if(i%20==0||!r.ok)console.error('level',i+1,r.ok?('solved in '+r.frames+' frames, salt '+sl):('FAILED '+r.why),((Date.now()-t0)/1000|0)+'s');
}
console.error('range',FROM,TO,'solved',ok,'of',TO-FROM,'avg frames',(tf/Math.max(ok,1))|0,'unsolved(HARD) levels',JSON.stringify(bad),'banned twists',JSON.stringify(bant));
fs.writeFileSync('salts_'+FROM+'_'+TO+'.json',JSON.stringify({salts:SALTS,unsolved:bad,bant}));
