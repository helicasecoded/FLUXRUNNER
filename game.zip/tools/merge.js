// Merges salts_*.json (bot results) into salts.js used by the game
const fs=require('fs');let S={},H=[],B={};
for(const f of fs.readdirSync('.').filter(f=>/^salts_\d+_\d+\.json$/.test(f))){const j=JSON.parse(fs.readFileSync(f));Object.assign(S,j.salts);H.push(...j.unsolved);Object.assign(B,j.bant||{})}
H.sort((a,b)=>a-b);
fs.writeFileSync('salts.js','var SALT='+JSON.stringify(S)+';var HARDL='+JSON.stringify(H)+';var BANT='+JSON.stringify(B)+';\n');
console.log('salted',Object.keys(S).length,'hard',H.length,'banned-twist levels',Object.keys(B).length);
